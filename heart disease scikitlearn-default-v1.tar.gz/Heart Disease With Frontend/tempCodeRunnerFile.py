
        st.error(f"❌ High Risk: The patient is likely to have heart disease.\n\n**Confidence: {probability:.2f}%**")
    else: